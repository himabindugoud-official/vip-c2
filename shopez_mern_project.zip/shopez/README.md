# ShopEZ — MERN E-Commerce Application

A full-stack e-commerce app built with MongoDB, Express, React, and Node.js.

## Project Structure

```
shopez/
├── client/          # React frontend (Vite)
└── server/          # Express backend
```

## Quick Start

### 1. Prerequisites
- Node.js v16+
- MongoDB (local or MongoDB Atlas)

### 2. Backend Setup

```bash
cd server
npm install
# Edit .env and set your MongoDB URI
npm start          # or: npx nodemon index.js
# Runs on http://localhost:8000
```

### 3. Frontend Setup

```bash
cd client
npm install
npm run dev
# Runs on http://localhost:5173
```

## Environment Variables (`server/.env`)

```
PORT=8000
MONGO_URI=mongodb://localhost:27017/shopez
JWT_SECRET=shopez_super_secret_key_2024
```

## Create Admin User

Register normally, then update the user's role in MongoDB:

```js
// In MongoDB shell or Compass
db.users.updateOne({ email: "admin@example.com" }, { $set: { role: "admin" } })
```

## Features

- **User**: Register, Login, Browse Products, Add to Cart, Checkout, View Orders
- **Admin**: Dashboard stats, Manage Products (CRUD), Manage Orders (update status), View Users

## API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| POST | /api/auth/register | Register |
| POST | /api/auth/login | Login |
| GET | /api/products | List products |
| POST | /api/products | Add product (admin) |
| GET | /api/cart | Get user cart |
| POST | /api/cart/add | Add to cart |
| POST | /api/orders | Place order |
| GET | /api/orders/my | User's orders |
| GET | /api/orders/all | All orders (admin) |
| GET | /api/admin/stats | Dashboard stats |
