const User = require('../models/User');
const Product = require('../models/Product');
const Order = require('../models/Order');
const Admin = require('../models/Admin');

exports.getDashboardStats = async (req, res) => {
  try {
    const [users, products, orders] = await Promise.all([
      User.countDocuments(),
      Product.countDocuments(),
      Order.find()
    ]);
    const revenue = orders.reduce((sum, o) => sum + o.totalAmount, 0);
    res.json({ totalUsers: users, totalProducts: products, totalOrders: orders.length, totalRevenue: revenue });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getAdminSettings = async (req, res) => {
  try {
    let admin = await Admin.findOne();
    if (!admin) admin = await Admin.create({ categories: ['Electronics', 'Fashion', 'Books', 'Home', 'Sports'], bannerImage: '' });
    res.json(admin);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateAdminSettings = async (req, res) => {
  try {
    let admin = await Admin.findOne();
    if (!admin) admin = new Admin();
    Object.assign(admin, req.body);
    await admin.save();
    res.json(admin);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
