const router = require('express').Router();
const { placeOrder, getUserOrders, getAllOrders, updateOrderStatus } = require('../controllers/orderController');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

router.post('/', authMiddleware, placeOrder);
router.get('/my', authMiddleware, getUserOrders);
router.get('/all', adminMiddleware, getAllOrders);
router.put('/:id/status', adminMiddleware, updateOrderStatus);

module.exports = router;
