const router = require('express').Router();
const { getDashboardStats, getAllUsers, getAdminSettings, updateAdminSettings } = require('../controllers/adminController');
const { adminMiddleware } = require('../middleware/auth');

router.use(adminMiddleware);
router.get('/stats', getDashboardStats);
router.get('/users', getAllUsers);
router.get('/settings', getAdminSettings);
router.put('/settings', updateAdminSettings);

module.exports = router;
