const router = require('express').Router();
const { getAllProducts, getProduct, createProduct, updateProduct, deleteProduct } = require('../controllers/productController');
const { adminMiddleware } = require('../middleware/auth');

router.get('/', getAllProducts);
router.get('/:id', getProduct);
router.post('/', adminMiddleware, createProduct);
router.put('/:id', adminMiddleware, updateProduct);
router.delete('/:id', adminMiddleware, deleteProduct);

module.exports = router;
