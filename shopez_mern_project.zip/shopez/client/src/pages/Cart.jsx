import { useCart } from '../context/CartContext';
import { useNavigate, Link } from 'react-router-dom';

export default function Cart() {
  const { cart, cartTotal, updateQty, removeItem } = useCart();
  const navigate = useNavigate();
  const items = cart.items || [];

  if (items.length === 0) return (
    <div className="cart-page">
      <h2 className="section-title">Shopping Cart</h2>
      <div className="empty-state"><div className="icon">🛒</div><h3>Your cart is empty</h3>
        <Link to="/products" className="btn btn-primary" style={{ marginTop: 16, display: 'inline-block' }}>Continue Shopping</Link>
      </div>
    </div>
  );

  return (
    <div className="cart-page">
      <h2 className="section-title">Shopping Cart ({items.length} items)</h2>
      {items.map(item => (
        <div key={item.productId} className="cart-item">
          <img src={item.image || `https://picsum.photos/seed/${item.productId}/200/200`} alt={item.productName}
            onError={e => { e.target.src = `https://picsum.photos/seed/${item.productId}/200/200`; }} />
          <div className="cart-item-info">
            <h4>{item.productName}</h4>
            <div className="price">₹{item.price.toLocaleString()}</div>
            <div className="qty-controls">
              <button onClick={() => updateQty(item.productId, item.quantity - 1)}>−</button>
              <span>{item.quantity}</span>
              <button onClick={() => updateQty(item.productId, item.quantity + 1)}>+</button>
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontWeight: 700, marginBottom: 8 }}>₹{(item.price * item.quantity).toLocaleString()}</div>
            <button className="btn btn-danger btn-sm" onClick={() => removeItem(item.productId)}>Remove</button>
          </div>
        </div>
      ))}
      <div className="cart-summary">
        <h3>Order Summary</h3>
        <div className="summary-row"><span>Subtotal</span><span>₹{cartTotal.toLocaleString()}</span></div>
        <div className="summary-row"><span>Delivery</span><span style={{ color: '#28a745' }}>FREE</span></div>
        <div className="summary-row total"><span>Total</span><span>₹{cartTotal.toLocaleString()}</span></div>
        <button className="btn btn-primary" style={{ width: '100%', marginTop: 16 }} onClick={() => navigate('/checkout')}>
          Proceed to Checkout
        </button>
      </div>
    </div>
  );
}
