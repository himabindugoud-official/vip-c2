import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import axios from 'axios';
import ProductCard from '../components/ProductCard';

export default function Home() {
  const [featured, setFeatured] = useState([]);

  useEffect(() => {
    axios.get('/api/products').then(({ data }) => setFeatured(data.slice(0, 4))).catch(() => {});
  }, []);

  return (
    <div>
      <section className="hero">
        <h1>Welcome to <span>ShopEZ</span></h1>
        <p>Your one-stop destination for effortless online shopping. Discover thousands of products with seamless checkout.</p>
        <div className="hero-btns">
          <Link to="/products" className="btn btn-primary">Shop Now</Link>
          <Link to="/register" className="btn btn-outline" style={{ borderColor: 'white', color: 'white' }}>Join Free</Link>
        </div>
      </section>

      <section className="products-section">
        <div className="container">
          <h2 className="section-title">✨ Featured Products</h2>
          {featured.length > 0 ? (
            <div className="products-grid">
              {featured.map(p => <ProductCard key={p._id} product={p} />)}
            </div>
          ) : (
            <div className="empty-state">
              <div className="icon">🛍️</div>
              <h3>No products yet. Add some from the Admin panel!</h3>
            </div>
          )}
          {featured.length > 0 && (
            <div style={{ textAlign: 'center', marginTop: 32 }}>
              <Link to="/products" className="btn btn-secondary">View All Products</Link>
            </div>
          )}
        </div>
      </section>

      <section style={{ background: 'white', padding: '60px 20px', textAlign: 'center' }}>
        <div className="container">
          <h2 style={{ fontSize: '1.8rem', fontWeight: 700, marginBottom: 40, color: '#1a1a2e' }}>Why ShopEZ?</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 32 }}>
            {[
              { icon: '🚀', title: 'Fast Checkout', desc: 'Complete your order in just a few clicks' },
              { icon: '🔒', title: 'Secure Payments', desc: 'Your data is always safe with us' },
              { icon: '📦', title: 'Order Tracking', desc: 'Track your orders in real-time' },
              { icon: '⭐', title: 'Best Quality', desc: 'Curated products from trusted sellers' },
            ].map(f => (
              <div key={f.title}>
                <div style={{ fontSize: '2.5rem', marginBottom: 12 }}>{f.icon}</div>
                <h4 style={{ fontWeight: 700, marginBottom: 8 }}>{f.title}</h4>
                <p style={{ color: '#666', fontSize: '0.9rem' }}>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
