import { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import AdminLayout from '../components/AdminLayout';
import { showToast } from '../components/Toast';

const emptyForm = { name: '', description: '', price: '', discountPrice: '', category: '', image: '', stock: '' };

export default function AdminProducts() {
  const [products, setProducts] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [editing, setEditing] = useState(null);
  const { token } = useAuth();
  const headers = { Authorization: `Bearer ${token}` };

  const load = () => axios.get('/api/products').then(({ data }) => setProducts(data)).catch(() => {});
  useEffect(() => { load(); }, []);

  const openAdd = () => { setForm(emptyForm); setEditing(null); setModal(true); };
  const openEdit = (p) => { setForm({ ...p, price: p.price, discountPrice: p.discountPrice || '', stock: p.stock }); setEditing(p._id); setModal(true); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const body = { ...form, price: Number(form.price), stock: Number(form.stock), discountPrice: form.discountPrice ? Number(form.discountPrice) : undefined };
    try {
      if (editing) {
        await axios.put(`/api/products/${editing}`, body, { headers });
        showToast('Product updated!');
      } else {
        await axios.post('/api/products', body, { headers });
        showToast('Product added!');
      }
      setModal(false); load();
    } catch (err) { showToast(err.response?.data?.message || 'Error', 'error'); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this product?')) return;
    try { await axios.delete(`/api/products/${id}`, { headers }); showToast('Deleted!'); load(); }
    catch { showToast('Delete failed', 'error'); }
  };

  const set = (f) => (e) => setForm({ ...form, [f]: e.target.value });

  return (
    <AdminLayout>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h2 className="section-title" style={{ margin: 0 }}>Products ({products.length})</h2>
        <button className="btn btn-primary" onClick={openAdd}>+ Add Product</button>
      </div>
      <table className="data-table">
        <thead><tr><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Actions</th></tr></thead>
        <tbody>
          {products.map(p => (
            <tr key={p._id}>
              <td><img src={p.image || `https://picsum.photos/seed/${p._id}/60/60`} style={{ width: 48, height: 48, objectFit: 'cover', borderRadius: 8, background: '#eee' }} onError={e => { e.target.src = `https://picsum.photos/seed/${p._id}/60/60`; }} /></td>
              <td><strong>{p.name}</strong></td>
              <td>{p.category}</td>
              <td>₹{p.price.toLocaleString()}{p.discountPrice && <span style={{ color: '#e94560', marginLeft: 6 }}>→ ₹{p.discountPrice}</span>}</td>
              <td>{p.stock}</td>
              <td style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-secondary btn-sm" onClick={() => openEdit(p)}>Edit</button>
                <button className="btn btn-danger btn-sm" onClick={() => handleDelete(p._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {modal && (
        <div className="modal-overlay" onClick={() => setModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h3>{editing ? 'Edit Product' : 'Add New Product'}</h3>
            <form onSubmit={handleSubmit}>
              <div className="form-group"><label>Name</label><input required value={form.name} onChange={set('name')} /></div>
              <div className="form-group"><label>Description</label><textarea required value={form.description} onChange={set('description')} /></div>
              <div className="form-group"><label>Category</label><input required value={form.category} onChange={set('category')} /></div>
              <div className="form-row">
                <div className="form-group"><label>Price (₹)</label><input type="number" required value={form.price} onChange={set('price')} /></div>
                <div className="form-group"><label>Discount Price (₹)</label><input type="number" value={form.discountPrice} onChange={set('discountPrice')} /></div>
              </div>
              <div className="form-row">
                <div className="form-group"><label>Stock</label><input type="number" required value={form.stock} onChange={set('stock')} /></div>
                <div className="form-group"><label>Image URL</label><input value={form.image} onChange={set('image')} /></div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-outline" onClick={() => setModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">{editing ? 'Update' : 'Add Product'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
