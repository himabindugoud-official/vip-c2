import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { showToast } from '../components/Toast';

export default function Checkout() {
  const { cart, cartTotal, clearCart } = useCart();
  const { token } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    fullName: '', address: '', city: '', state: '', pincode: '', phone: '', paymentMethod: 'COD'
  });

  const items = cart.items || [];

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (items.length === 0) { showToast('Cart is empty', 'error'); return; }
    setLoading(true);
    try {
      const { paymentMethod, ...shippingAddress } = form;
      await axios.post('/api/orders', {
        items: items.map(i => ({ productId: i.productId, productName: i.productName, price: i.price, quantity: i.quantity, image: i.image })),
        totalAmount: cartTotal, shippingAddress, paymentMethod
      }, { headers: { Authorization: `Bearer ${token}` } });
      clearCart();
      showToast('Order placed successfully! 🎉');
      navigate('/profile');
    } catch (err) {
      showToast(err.response?.data?.message || 'Order failed', 'error');
    } finally { setLoading(false); }
  };

  const set = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  if (items.length === 0) {
    navigate('/cart');
    return null;
  }

  return (
    <div className="checkout-page">
      <h2 className="section-title">Checkout</h2>
      <form onSubmit={handleSubmit}>
        <div className="checkout-section">
          <h3>📦 Shipping Address</h3>
          <div className="form-group"><label>Full Name</label><input required value={form.fullName} onChange={set('fullName')} /></div>
          <div className="form-group"><label>Address</label><textarea required value={form.address} onChange={set('address')} /></div>
          <div className="form-row">
            <div className="form-group"><label>City</label><input required value={form.city} onChange={set('city')} /></div>
            <div className="form-group"><label>State</label><input required value={form.state} onChange={set('state')} /></div>
          </div>
          <div className="form-row">
            <div className="form-group"><label>Pincode</label><input required value={form.pincode} onChange={set('pincode')} /></div>
            <div className="form-group"><label>Phone</label><input required value={form.phone} onChange={set('phone')} /></div>
          </div>
        </div>
        <div className="checkout-section">
          <h3>💳 Payment Method</h3>
          {['COD', 'UPI', 'Card', 'NetBanking'].map(m => (
            <label key={m} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12, cursor: 'pointer' }}>
              <input type="radio" name="payment" value={m} checked={form.paymentMethod === m} onChange={set('paymentMethod')} />
              <span>{m === 'COD' ? '💵 Cash on Delivery' : m === 'UPI' ? '📱 UPI' : m === 'Card' ? '💳 Credit/Debit Card' : '🏦 Net Banking'}</span>
            </label>
          ))}
        </div>
        <div className="checkout-section">
          <h3>🛒 Order Summary</h3>
          {items.map(i => (
            <div key={i.productId} className="summary-row">
              <span>{i.productName} × {i.quantity}</span>
              <span>₹{(i.price * i.quantity).toLocaleString()}</span>
            </div>
          ))}
          <div className="summary-row total"><span>Total</span><span>₹{cartTotal.toLocaleString()}</span></div>
        </div>
        <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: 16, fontSize: '1.05rem' }} disabled={loading}>
          {loading ? 'Placing Order...' : `Place Order — ₹${cartTotal.toLocaleString()}`}
        </button>
      </form>
    </div>
  );
}
