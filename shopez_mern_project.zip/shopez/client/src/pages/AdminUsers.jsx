import { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import AdminLayout from '../components/AdminLayout';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const { token } = useAuth();

  useEffect(() => {
    axios.get('/api/admin/users', { headers: { Authorization: `Bearer ${token}` } })
      .then(({ data }) => setUsers(data)).catch(() => {});
  }, []);

  return (
    <AdminLayout>
      <h2 className="section-title">All Users ({users.length})</h2>
      <table className="data-table">
        <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th></tr></thead>
        <tbody>
          {users.map(u => (
            <tr key={u._id}>
              <td><strong>{u.username}</strong></td>
              <td>{u.email}</td>
              <td><span style={{ padding: '3px 10px', borderRadius: 20, fontSize: '0.8rem', background: u.role === 'admin' ? '#ffd700' : '#e0f0e0', color: u.role === 'admin' ? '#333' : '#155724' }}>{u.role}</span></td>
              <td>{new Date(u.createdAt).toLocaleDateString('en-IN')}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </AdminLayout>
  );
}
