import { useState, useEffect } from 'react';
import axios from 'axios';
import ProductCard from '../components/ProductCard';

export default function Products() {
  const [products, setProducts] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [loading, setLoading] = useState(true);
  const categories = [...new Set(products.map(p => p.category))];

  useEffect(() => {
    axios.get('/api/products').then(({ data }) => { setProducts(data); setFiltered(data); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    let result = products;
    if (search) result = result.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));
    if (category) result = result.filter(p => p.category === category);
    setFiltered(result);
  }, [search, category, products]);

  if (loading) return <div className="loading"><div className="spinner"></div>Loading products...</div>;

  return (
    <section className="products-section">
      <div className="container">
        <h2 className="section-title">All Products ({filtered.length})</h2>
        <div className="filters">
          <input placeholder="🔍 Search products..." value={search} onChange={e => setSearch(e.target.value)} />
          <select value={category} onChange={e => setCategory(e.target.value)}>
            <option value="">All Categories</option>
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          {(search || category) && (
            <button className="btn btn-outline btn-sm" onClick={() => { setSearch(''); setCategory(''); }}>Clear</button>
          )}
        </div>
        {filtered.length === 0 ? (
          <div className="empty-state">
            <div className="icon">🔍</div>
            <h3>No products found</h3>
          </div>
        ) : (
          <div className="products-grid">
            {filtered.map(p => <ProductCard key={p._id} product={p} />)}
          </div>
        )}
      </div>
    </section>
  );
}
