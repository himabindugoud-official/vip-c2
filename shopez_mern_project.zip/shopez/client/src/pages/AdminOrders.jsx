import { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import AdminLayout from '../components/AdminLayout';
import { showToast } from '../components/Toast';

const STATUSES = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];

export default function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const { token } = useAuth();
  const headers = { Authorization: `Bearer ${token}` };

  const load = () => axios.get('/api/orders/all', { headers }).then(({ data }) => setOrders(data)).catch(() => {});
  useEffect(() => { load(); }, []);

  const updateStatus = async (id, status) => {
    try {
      await axios.put(`/api/orders/${id}/status`, { status }, { headers });
      showToast('Status updated!');
      load();
    } catch { showToast('Update failed', 'error'); }
  };

  return (
    <AdminLayout>
      <h2 className="section-title">All Orders ({orders.length})</h2>
      <table className="data-table">
        <thead><tr><th>Order ID</th><th>Customer</th><th>Items</th><th>Total</th><th>Payment</th><th>Date</th><th>Status</th></tr></thead>
        <tbody>
          {orders.map(o => (
            <tr key={o._id}>
              <td><code style={{ fontSize: '0.8rem' }}>#{o._id.slice(-8).toUpperCase()}</code></td>
              <td>{o.userId?.username || 'N/A'}<br /><span style={{ color: '#888', fontSize: '0.8rem' }}>{o.userId?.email}</span></td>
              <td>{o.items.map(i => `${i.productName} ×${i.quantity}`).join(', ')}</td>
              <td><strong>₹{o.totalAmount.toLocaleString()}</strong></td>
              <td>{o.paymentMethod}</td>
              <td>{new Date(o.orderDate).toLocaleDateString('en-IN')}</td>
              <td>
                <select value={o.status} onChange={e => updateStatus(o._id, e.target.value)}
                  style={{ padding: '4px 8px', borderRadius: 6, border: '1px solid #ddd', fontSize: '0.85rem' }}>
                  {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </AdminLayout>
  );
}
