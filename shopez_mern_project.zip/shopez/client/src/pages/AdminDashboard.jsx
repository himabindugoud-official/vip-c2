import { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import AdminLayout from '../components/AdminLayout';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const { token } = useAuth();

  useEffect(() => {
    axios.get('/api/admin/stats', { headers: { Authorization: `Bearer ${token}` } })
      .then(({ data }) => setStats(data)).catch(() => {});
  }, []);

  return (
    <AdminLayout>
      <h2 className="section-title">Dashboard</h2>
      <div className="stats-grid">
        {[
          { label: 'Total Users', value: stats?.totalUsers ?? '—', icon: '👥' },
          { label: 'Total Products', value: stats?.totalProducts ?? '—', icon: '📦' },
          { label: 'Total Orders', value: stats?.totalOrders ?? '—', icon: '🛒' },
          { label: 'Total Revenue', value: stats ? `₹${stats.totalRevenue.toLocaleString()}` : '—', icon: '💰' },
        ].map(s => (
          <div key={s.label} className="stat-card">
            <div style={{ fontSize: '2rem', marginBottom: 8 }}>{s.icon}</div>
            <div className="stat-value">{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>
      <div style={{ background: 'white', borderRadius: 12, padding: 24, boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
        <h3 style={{ marginBottom: 16 }}>Quick Actions</h3>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <a href="/admin/products" className="btn btn-primary">+ Add Product</a>
          <a href="/admin/orders" className="btn btn-secondary">View Orders</a>
        </div>
      </div>
    </AdminLayout>
  );
}
