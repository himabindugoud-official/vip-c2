import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { showToast } from '../components/Toast';

export default function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const { addToCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    axios.get(`/api/products/${id}`).then(({ data }) => { setProduct(data); setLoading(false); }).catch(() => setLoading(false));
  }, [id]);

  const handleAddToCart = async () => {
    if (!user) { showToast('Please login first', 'error'); navigate('/login'); return; }
    const ok = await addToCart(product);
    if (ok) showToast('Added to cart!');
  };

  const handleBuyNow = async () => {
    if (!user) { showToast('Please login first', 'error'); navigate('/login'); return; }
    await addToCart(product);
    navigate('/checkout');
  };

  if (loading) return <div className="loading"><div className="spinner"></div></div>;
  if (!product) return <div className="empty-state"><h3>Product not found</h3></div>;

  const discount = product.discountPrice ? Math.round((1 - product.discountPrice / product.price) * 100) : 0;

  return (
    <div className="product-detail">
      <div>
        <img
          src={product.image || `https://picsum.photos/seed/${product._id}/600/500`}
          alt={product.name}
          onError={e => { e.target.src = `https://picsum.photos/seed/${product._id}/600/500`; }}
        />
      </div>
      <div className="product-detail-info">
        <div className="category">{product.category}</div>
        <h1>{product.name}</h1>
        <div className="price">
          ₹{(product.discountPrice || product.price).toLocaleString()}
          {product.discountPrice && (
            <span style={{ fontSize: '1rem', color: '#999', textDecoration: 'line-through', marginLeft: 12 }}>
              ₹{product.price.toLocaleString()}
            </span>
          )}
          {discount > 0 && <span style={{ fontSize: '0.9rem', color: '#28a745', marginLeft: 8, fontWeight: 600 }}>{discount}% OFF</span>}
        </div>
        <p>{product.description}</p>
        <p style={{ color: product.stock > 0 ? '#28a745' : '#dc3545', fontWeight: 600, marginBottom: 24 }}>
          {product.stock > 0 ? `✓ In Stock (${product.stock} available)` : '✗ Out of Stock'}
        </p>
        <div className="product-detail-actions">
          <button className="btn btn-outline" onClick={handleAddToCart} disabled={product.stock === 0}>Add to Cart</button>
          <button className="btn btn-primary" onClick={handleBuyNow} disabled={product.stock === 0}>Buy Now</button>
        </div>
      </div>
    </div>
  );
}
