import { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function Profile() {
  const { user, token } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (!token) { navigate('/login'); return; }
    axios.get('/api/orders/my', { headers: { Authorization: `Bearer ${token}` } })
      .then(({ data }) => { setOrders(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [token]);

  if (loading) return <div className="loading"><div className="spinner"></div></div>;

  return (
    <div className="profile-page">
      <div className="profile-header">
        <div className="profile-avatar">{user?.username?.[0]?.toUpperCase()}</div>
        <div className="profile-info">
          <h2>{user?.username}</h2>
          <p>{user?.email}</p>
          <p style={{ marginTop: 4, fontSize: '0.85rem', background: 'rgba(255,255,255,0.15)', display: 'inline-block', padding: '2px 10px', borderRadius: 20 }}>{user?.role}</p>
        </div>
      </div>

      <h3 className="section-title">My Orders ({orders.length})</h3>
      {orders.length === 0 ? (
        <div className="empty-state"><div className="icon">📦</div><h3>No orders yet</h3></div>
      ) : orders.map(order => (
        <div key={order._id} className="order-card">
          <div className="order-card-header">
            <div>
              <strong>Order #{order._id.slice(-8).toUpperCase()}</strong>
              <div style={{ fontSize: '0.85rem', color: '#888', marginTop: 2 }}>
                {new Date(order.orderDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
              </div>
            </div>
            <span className={`status-badge status-${order.status}`}>{order.status}</span>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
            {order.items.map(item => (
              <div key={item.productId} style={{ background: '#f5f5f5', borderRadius: 8, padding: '6px 12px', fontSize: '0.85rem' }}>
                {item.productName} × {item.quantity}
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ color: '#888', fontSize: '0.85rem' }}>Payment: {order.paymentMethod}</span>
            <span style={{ fontWeight: 700, color: '#e94560', fontSize: '1.05rem' }}>₹{order.totalAmount.toLocaleString()}</span>
          </div>
        </div>
      ))}
    </div>
  );
}
