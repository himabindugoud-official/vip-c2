import { Link, useLocation, Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function AdminLayout({ children }) {
  const { isAdmin, loading } = useAuth();
  const location = useLocation();

  if (loading) return <div className="loading"><div className="spinner"></div></div>;
  if (!isAdmin) return <Navigate to="/login" />;

  const links = [
    { to: '/admin', label: '📊 Dashboard' },
    { to: '/admin/products', label: '📦 Products' },
    { to: '/admin/orders', label: '🛒 Orders' },
    { to: '/admin/users', label: '👥 Users' },
  ];

  return (
    <div className="admin-layout">
      <aside className="admin-sidebar">
        <h3>Admin Panel</h3>
        {links.map(l => (
          <Link key={l.to} to={l.to} className={location.pathname === l.to ? 'active' : ''}>{l.label}</Link>
        ))}
      </aside>
      <main className="admin-content">{children}</main>
    </div>
  );
}
