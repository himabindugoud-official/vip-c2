import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

export default function Navbar() {
  const { user, logout, isAdmin } = useAuth();
  const { cartCount } = useCart();
  const navigate = useNavigate();

  const handleLogout = () => { logout(); navigate('/'); };

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="navbar-logo">ShopEZ</Link>
        <div className="navbar-links">
          <Link to="/products"><span>Products</span></Link>
          {user ? (
            <>
              <Link to="/cart" className="cart-badge">
                🛒 <span>Cart</span>
                {cartCount > 0 && <span className="badge">{cartCount}</span>}
              </Link>
              <Link to="/profile"><span>Profile</span></Link>
              {isAdmin && <Link to="/admin">Admin</Link>}
              <button onClick={handleLogout}>Logout</button>
            </>
          ) : (
            <>
              <Link to="/login">Login</Link>
              <Link to="/register" style={{ background: '#e94560', borderRadius: 8, padding: '8px 16px' }}>Sign Up</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
