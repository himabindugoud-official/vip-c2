import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { showToast } from './Toast';

export default function ProductCard({ product }) {
  const { addToCart } = useCart();
  const { user } = useAuth();

  const handleAddToCart = async (e) => {
    e.preventDefault();
    if (!user) { showToast('Please login to add to cart', 'error'); return; }
    const ok = await addToCart(product);
    if (ok) showToast('Added to cart!');
    else showToast('Failed to add to cart', 'error');
  };

  return (
    <div className="product-card">
      <Link to={`/products/${product._id}`}>
        <img
          src={product.image || `https://picsum.photos/seed/${product._id}/400/300`}
          alt={product.name}
          onError={e => { e.target.src = `https://picsum.photos/seed/${product._id}/400/300`; }}
        />
      </Link>
      <div className="card-body">
        <div className="category">{product.category}</div>
        <h3>{product.name}</h3>
        <div className="price">₹{(product.discountPrice || product.price).toLocaleString()}</div>
        {product.discountPrice && (
          <div className="original-price">₹{product.price.toLocaleString()}</div>
        )}
        <div className="card-actions">
          <Link to={`/products/${product._id}`} className="btn btn-outline btn-sm">View</Link>
          <button className="btn btn-primary btn-sm" onClick={handleAddToCart}>Add to Cart</button>
        </div>
      </div>
    </div>
  );
}
