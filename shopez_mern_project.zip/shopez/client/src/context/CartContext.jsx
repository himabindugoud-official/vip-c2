import { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';

const CartContext = createContext();

export function CartProvider({ children }) {
  const [cart, setCart] = useState({ items: [] });
  const { token } = useAuth();

  const headers = token ? { Authorization: `Bearer ${token}` } : {};

  const fetchCart = async () => {
    if (!token) return;
    try {
      const { data } = await axios.get('/api/cart', { headers });
      setCart(data);
    } catch {}
  };

  useEffect(() => { fetchCart(); }, [token]);

  const addToCart = async (product, quantity = 1) => {
    if (!token) return false;
    try {
      const { data } = await axios.post('/api/cart/add', {
        productId: product._id, productName: product.name,
        price: product.discountPrice || product.price,
        quantity, image: product.image
      }, { headers });
      setCart(data);
      return true;
    } catch { return false; }
  };

  const updateQty = async (productId, quantity) => {
    try {
      const { data } = await axios.put('/api/cart/update', { productId, quantity }, { headers });
      setCart(data);
    } catch {}
  };

  const removeItem = async (productId) => {
    try {
      const { data } = await axios.delete(`/api/cart/remove/${productId}`, { headers });
      setCart(data);
    } catch {}
  };

  const clearCart = () => setCart({ items: [] });

  const cartCount = cart.items?.reduce((sum, i) => sum + i.quantity, 0) || 0;
  const cartTotal = cart.items?.reduce((sum, i) => sum + i.price * i.quantity, 0) || 0;

  return (
    <CartContext.Provider value={{ cart, cartCount, cartTotal, addToCart, updateQty, removeItem, clearCart, fetchCart }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);
